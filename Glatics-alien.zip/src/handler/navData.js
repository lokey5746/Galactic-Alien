import opensea from "../img/opensea.png";
import twitter from "../img/twitter.png";
import discord from "../img/discord.png";
import instagram from "../img/instagram.png";

export const links = [
  {
    id: 1,
    url: "about",
    text: "About",
  },

  {
    id: 2,
    url: "roadmap",
    text: "Roadmap",
  },
  {
    id: 3,
    url: "faq",
    text: "FAQs",
  },
  {
    id: 4,
    url: "team",
    text: "Team",
  },
];

export const social = [
  {
    id: 1,
    url: "https://twitter.com",
    icon: twitter,
  },
  {
    id: 2,
    url: "https://www.instagram.com",
    icon: instagram,
  },
  {
    id: 3,
    url: "https://www.twitter.com",
    icon: opensea,
  },
  {
    id: 4,
    url: "https://discord.gg/",
    icon: discord,
  },
];
