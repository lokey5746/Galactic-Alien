import team1 from "../img/Team-1.png";
import team2 from "../img/Team-2.png";
import team3 from "../img/Team-3.png";
import team4 from "../img/Team-4.png";
import team5 from "../img/Team-5.png";
import team6 from "../img/Team-6.png";
import team7 from "../img/Team-7.png";

export default [
  {
    id: 1,
    image: team1,
    name: "Bule",
    role: "FOUNDER",
  },
  {
    id: 2,
    image: team2,
    name: "Maja",
    role: "DISCORD EXPERT",
  },
  {
    id: 3,
    image: team3,
    name: "Anthony",
    role: "COMMUNITY MANAGER",
  },
  {
    id: 4,
    image: team4,
    name: "Dushan",
    role: "EVENT MANAGER",
  },

  {
    id: 5,
    image: team5,
    name: "Clint",
    role: "MODERATOR",
  },
  {
    id: 6,
    image: team6,
    name: "Hamad",
    role: "DESIGNER",
  },
  {
    id: 7,
    image: team7,
    name: "mr_sudeep",
    role: "NFT EXPERT",
  },
  {
    id: 8,
    image: team1,
    name: "Mr_Sudeep",
    role: "NFT EXPERT",
  },
];
