import banner from "../img/Banner.png";

function Banner() {
  return (
    <figure>
      <img className="w-full" src={banner} alt="Banner" />
    </figure>
  );
}

export default Banner;
