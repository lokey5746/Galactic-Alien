import React, { useState } from "react";
import teamData from "../handler/teamData";

function Team() {
  const [teams, setTeams] = useState(teamData);

  return (
    <section className="px-8 md:px-32 mx-auto md:py-10" id="team">
      <div className="flex flex-col items-center space-y-5 py-10">
        <h2 className="text-3xl md:text-5xl text-center font-semibold font-Kalam text-primary  tracking-wide">
          The Team
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 md:gap-10">
          {teams.map((team) => (
            <figure key={team.id} className="flex flex-col items-center">
              <img src={team.image} alt="" />
              <h2 className="text-primary font-Kalam text-center text-lg md:text-2xl my-3">
                {team.name}
              </h2>
              <div className="">
                <p className="text-center uppercase text-sm  font-semibold text-white font-Opensans">
                  {team.role}
                </p>
              </div>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Team;
